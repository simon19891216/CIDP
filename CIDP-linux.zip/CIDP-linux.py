#!/usr/bin/env python
# -*- coding:utf-8 -*-


import argparse
import re,os,subprocess,pickle,math,stat



def argparseFunc():
    parser = argparse.ArgumentParser(description="design sgRNA")
    #the input files
    parser.add_argument("-gf","--genome_file",help="genome-sequence file")
    parser.add_argument("-ff","--fasta_file",help="gene-sequence/CDS file or gene sequence (only sequence, need to remove other symbols)")
    parser.add_argument("-sf","--sgRNA_file",help="the file containing sgRNAs")
    parser.add_argument("-df","--database_file",help="the pathway of database file")
    parser.add_argument("-gff_file",help="the gff-format file")
    parser.add_argument("-gtf_file",help="the gtf-format file")
    parser.add_argument("-bed_file",help="the file containing gene-position information. the format:gene ID/chr ID/start_position/end_position/positive or negative chain. e.g. ARF4 chr1 10000 15000 +")
    parser.add_argument("-ID_file",help="the file containing ID or IDs, and the IDs should be consistent with the IDs corresponding to the IDs of mRNA")
    #the save file
    parser.add_argument("-o","--out",help="save path")
    #the functions
    parser.add_argument("-md","--make_database",action="store_true",help="the input should be the genomic sequecne file")
    parser.add_argument("-ss","--search_sgRNA",action="store_true",help="search sgRNAs")
    parser.add_argument("-show_pams",action="store_true",help="show pam")
    # parser.add_argument("-dp","--design_primer",action="store_true",help="should input sgRNAs")
    parser.add_argument("-fs","--filter_sgRNA",action="store_true",help="filter sgRNAs")
    parser.add_argument("-ah","--add_hairpin",action="store_true",help="add hairpin structures to sgRNAs")
    parser.add_argument("-ad","--add_gold",action="store_true",help="add gold structures to sgRNAs")
    parser.add_argument("-exp","--extract_promoter",action="store_true",help="extract promoters from genomic sequence based on IDs")
    parser.add_argument("-ext","--extract_total",action="store_true",help="extract total sequences of a gene from genomic sequence based on IDs")
    parser.add_argument("-ex5","--extract_5utr",action="store_true",help="extract the sequence of 5'utr. Note, CIDP will extract the sequence based on the gff file. If the 5'utr information was abscent from the gff file, this function will not work")
    parser.add_argument("-ex3","--extract_3utr",action="store_true",help="extract the sequence of 3'utr. Note, CIDP will extract the sequence based on the gff file. If the 3'utr information was abscent from the gff file, this function will not work")
    parser.add_argument("-excds","--extract_cds",action="store_true",help="extract CDS sequence from CDS file. CDS: coding sequence")
    parser.add_argument("-exbed","--extract_bed",action="store_true",help="extract sequences based on bed file")
    parser.add_argument("-exids","--extract_ids",action="store_true",help="extract IDs from gff file")
    parser.add_argument("-formatgtf",action="store_true",help="format gff to gtf")
    #parameters
    parser.add_argument("-sl", "--sgRNA_length",type=int,default=20,help="the length of sgRNA, and the default value is 20")
    parser.add_argument("-misnumber",type=str,default="5",help="mismatch number of bases during sequence alignment")
    parser.add_argument("-cs", "--common_sgRNA",action="store_true",help="find sgRNAs shared by several genes")
    parser.add_argument("-pam",default="NGG",help="the parameter,all_pam, will show all pams")
    parser.add_argument("-not_unique",action="store_true",help="will save sgRNAs without unique")
    # parser.add_argument("-left_region",action="store_true",help="the sequence on the left side of the sgRNA insert site")
    # parser.add_argument("-right_region",action="store_true",help="the sequence on the right side of the sgRNA insert site")
    parser.add_argument("-fp", "--filter_percent",type=int,default=20,help="the percent of filtering the sgRNAs")
    parser.add_argument("-gr", "--gc_range",default="30-80",help="the GC range of sgRNAs")
    parser.add_argument("-hairpin", default="ACAA",help="add the hairpin structure to sgRNAs")
    parser.add_argument("-gs", "--gold_structure",default="AAGGCTAGTCCGTTATCAACTTGGACTTCGGTCCAAGTGGCACCGAGTCGGTGCTTT",help="add the gold structure to sgRNAs")
    parser.add_argument("-pl", "--promoter_length",type=int,default=2000,help="the required length of promoters")
    return parser.parse_args()

def reverse_complement(sequence):
        trantab = str.maketrans('ACGTagct\n', 'TGCATCGA\n')
        string = sequence.translate(trantab)
        reverse_complement = string[::-1]
        return reverse_complement

def make_database(file,save,sgrna_l):
    seqdir={};chr_kmer={}
    command="awk '/^>/{print n $1; n = \"\\n\"} !/^>/{printf \"%s\",$0}'"+" {} > {}".format(file,file+"_format.txt")
    os.system(command)
    with open(file+"_format.txt",encoding="utf-8") as f:
        for line in f:
            if ">" in line:
                ID=line.split()[0]
                seqdir[ID]=""
            else:seqdir[ID]=line.strip()
    for seq in seqdir.values():
        for i in range(0,len(seq)-sgrna_l+1):
            if "N" not in seq[i:i+sgrna_l]:
                if seq[i:i+sgrna_l] not in chr_kmer:
                    chr_kmer[seq[i:i+sgrna_l]]=1
                else:chr_kmer[seq[i:i+sgrna_l]]+=1
                if reverse_complement(seq[i:i+sgrna_l]) not in chr_kmer:
                    chr_kmer[reverse_complement(seq[i:i+sgrna_l])]=1
                else:chr_kmer[reverse_complement(seq[i:i+sgrna_l])]+=1
    with open(save,"w",encoding="utf-8") as f:
        [f.write(kmer+"\n") for kmer,num in chr_kmer.items() if num==1]
    chr_kmer={}
    os.remove(file+"_format.txt")

def calc_score(s):
    s_list = list(s)
    s_20mer = s[4:24]
    score = 0.597636154
    gc = s_20mer.count('G')+s_20mer.count('C')
    gc_low = -0.202625894
    gc_high = -0.166587752
    if gc < 10:
        gc_val = abs(gc-10)
        score = score+(gc_val*gc_low)
    elif gc > 10:
        gc_val = gc-10
        score = score+(gc_val*gc_high)
    sing_nuc_hash = {'G2':-0.275377128,'A3':-0.323887456,'C3':0.172128871,'C4':-0.100666209,'C5':-0.20180294, \
                    'G5':0.245956633,'A6':0.036440041,'C6':0.098376835,'C7':-0.741181291,\
                    'G7':-0.393264397,'A12':-0.466099015,'A15':0.085376945,'C15':-0.013813972,\
                    'A16':0.272620512,'C16':-0.119022648,'T16':-0.285944222,'A17':0.097454592,\
                    'G17':-0.17554617,'C18':-0.345795451,'G18':-0.678096426,'A19':0.22508903,\
                    'C19':-0.507794051,'G20':-0.417373597,'T20':-0.054306959,'G21':0.379899366,\
                    'T21':-0.090712644,'C22':0.057823319,'T22':-0.530567296,'T23':-0.877007428,\
                    'C24':-0.876235846,'G24':0.278916259,'T24':-0.403102218,'A25':-0.077300704,\
                    'C25':0.287935617,'T25':-0.221637217,'G28':-0.689016682,'T28':0.117877577,\
                    'C29':-0.160445304,'G30':0.386342585}
    dinuc_hash = {'GT2':-0.625778696,'GC5':0.300043317,'AA6':-0.834836245,'TA6':0.760627772,'GG7':-0.490816749,'GG12':-1.516907439,'TA12':0.7092612,'TC12':0.496298609,'TT12':-0.586873894,'GG13':-0.334563735,'GA14':0.76384993,'GC14':-0.53702517,'TG17':-0.798146133,'GG19':-0.66680873,'TC19':0.353183252,'CC20':0.748072092,'TG20':-0.367266772,'AC21':0.568209132,'CG21':0.329072074,'GA21':-0.836456755,'GG21':-0.782207584,'TC22':-1.029692957,'CG23':0.856197823,'CT23':-0.463207679,'AA24':-0.579492389,'AG24':0.649075537,'AG25':-0.077300704,'CG25':0.287935617,'TG25':-0.221637217,'GT27':0.117877577,'GG29':-0.697740024}
    for i,nuc in enumerate(s_list):
        key = nuc+str(i+1)
        if key in sing_nuc_hash:
            nuc_score = sing_nuc_hash[key]
        else:
            nuc_score = 0
        score = score+nuc_score
        if i<29:
            if i+1>len(s)-1:i=len(s)-2
            dinuc = nuc+s[i+1]+str(i+1)
            if dinuc in dinuc_hash.keys():
                score = score+dinuc_hash[dinuc]
    partial_score = math.e**-score
    final_score = 1/(1+partial_score)
    return final_score

def get_mm_pam_scores():
    try:
        mm_scores = pickle.load(open('./source/mismatch_score.pkl','rb'))
        pam_scores = pickle.load(open('./source/pam_scores.pkl','rb'))
        return (mm_scores,pam_scores)
    except: 
        raise Exception("Could not find file with mismatch scores or PAM scores")

def revcom(s):
        basecomp = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A','U':'A'}
        letters = list(s[::-1])
        letters = [basecomp[base] for base in letters]
        return ''.join(letters)

def calc_cfd(wt,sg,pam):
    mm_scores,pam_scores = get_mm_pam_scores()
    score = 1
    sg = sg.replace('T','U')
    wt = wt.replace('T','U')
    s_list = list(sg)
    wt_list = list(wt)
    for i,sl in enumerate(s_list):
        if wt_list[i] == sl:
            score*=1
        else:
            key = 'r'+wt_list[i]+':d'+revcom(sl)+','+str(i+1)
            score*= mm_scores[key]
    score*=pam_scores[pam]
    return (score)
        
def findsingle(sequence,sgRNA_length,databasename,pam,not_unique=False):
    positive_chains=[];negative_chains=[]
    sequence_r=reverse_complement(sequence)
    if pam in pams:
        for pam in pams[pam]:
            numb=[m.start() for m in re.finditer(pam,sequence)]
            numb_r=[n.start() for n in re.finditer(pam,sequence_r)]
            positive_chains+=numb
            negative_chains+=numb_r
    else:
        numb=[m.start() for m in re.finditer(pam,sequence)]
        numb_r=[n.start() for n in re.finditer(pam,sequence_r)]
        positive_chains+=numb
        negative_chains+=numb_r
    targetseq={sequence[i-sgRNA_length:i]:1 for i in positive_chains if i>=sgRNA_length}
    targetseq_r={reverse_complement(sequence_r[i-sgRNA_length:i]):-1 for i in negative_chains if i>=sgRNA_length}
    targetseq.update(targetseq_r)
    del targetseq_r
    seekseq=False
    with open(databasename,encoding="utf-8") as f:
        for line in f:
            target=line.strip()
            if target in targetseq:
                seekseq=True
                targetseq[target]*=10
    if not_unique==False and seekseq==True:
        targetseqf={target:num for target,num in targetseq.items() if num==10 or num==-10}
    else:targetseqf={target:2*num if num==1 or num==-1 else num for target,num in targetseq.items()}
    return targetseqf

def common_sgRNA(path,pam,k):
    with open(path,encoding="utf-8") as f:
        line =f.readline()
        j=0
        seq=""
        while line:
            line=line.strip()
            if line[0] ==">":
                if j==1:
                    positive_chains=[];negative_chains=[]
                    seq_r=reverse_complement(seq)
                    for pam in pams[pam]:
                        numb=[m.start() for m in re.finditer(pam,seq)]
                        numb_r=[n.start() for n in re.finditer(pam,seq_r)]
                    positive_chains+=numb
                    negative_chains+=numb_r
                    targetset={seq[i-k:i] for i in positive_chains if i>=k}
                    targetset_r={reverse_complement(seq_r[i-k:i]) for i in negative_chains if i>=k}
                    targetset.update(targetset_r)
                    del targetset_r
                    targetseq={i:1 for i in targetset}
                else:
                    gRNAS=set()
                    for i in range(len(seq)-k+1):
                        if seq[i:i+k] in targetseq and seq[i:i+k] not in gRNAS:
                            targetseq[seq[i:i+k]]+=1
                            gRNAS.add(seq[i:i+k])
                j+=1
            else:
                seq+=line
            line=f.readline()
        gRNAS=set()
        for i in range(len(seq)-k+1):
            if seq[i:i+k] in targetseq and seq[i:i+k] not in gRNAS:
                targetseq[seq[i:i+k]]+=1
                gRNAS.add(seq[i:i+k])
    return targetseq

def find_sgRNA2(seq,targetfile,genome,save,sgRNA_length,databasename,pam,misnumber,name="",cs=False,not_unique=False):
    targetseq={};target_mis={}
    if cs==False:
        targetseq.update(findsingle(seq,sgRNA_length,databasename,pam,not_unique=not_unique))
    else:
        targetseq=common_sgRNA(targetfile,pam,sgRNA_length)
        with open(targetfile,encoding="utf-8") as f:
            seq_dir={}
            for line in f:
                if line.startswith(">"):
                    ID=line.split()[0]
                    if ID not in seq_dir:
                        seq_dir[ID]=""
                else:
                    seq_dir[ID]+=line.strip()
        for ID,content in seq_dir.items():
            seq=content
            break
    targetfile="./targetseq.txt"
    genomefile=genome+" "
    alignmentfile=os.path.dirname(save)+"/algnment_result_"+name+".txt"
    if targetseq!={}:
        with open(targetfile,"w",encoding="utf-8") as f:
            [f.write(">target_"+content+"\n"+content+"\n") if num==10 or num==-10 else f.write(">target_"+content+"_not_unique\n"+content+"\n") for content,num in targetseq.items()]
        if misnumber=="":misnumber="5"
        if os.access("./bin/seqmap",os.X_OK)==False:os.chmod("./bin/seqmap",stat.S_IXUSR)
        argue='python alignment.py -ss -count '+misnumber+' -ff '+targetfile+' -gf '+genomefile+' -o '+alignmentfile
        result=subprocess.Popen(argue,shell=True)
        result.wait()
        with open(alignmentfile,encoding="utf-8") as f:
            for line in f:
                linelist=line.split("\t")
                t=linelist[4];m=linelist[2]
                if t!="probe_seq" and t not in target_mis:
                    target_mis[t]=[]
                if t in target_mis:
                    target_mis[t].append(m)
        sgRNA_dir={i:str(seq.index(i)+1)+"+" if num>0 else str(seq.index(i)+1)+"-" for i,num in targetseq.items()}
        off_dir={}#收录的是sgRNA和含有pam的
        targetoffsite={}
        if pam=="NGG":
            for i in target_mis:
                if len(i)<=20:
                    off_dir={seqs:seqs+seq[int(pos[:-1])+20:int(pos[:-1])+23] if "+" in pos else reverse_complement(seq[int(pos[:-1])-3:int(pos[:-1])]+seqs) for seqs,pos in sgRNA_dir.items()}
                    gRNA=off_dir[i][-2:]
                    if i not in targetoffsite:
                        targetoffsite[i]=0
                        for j in i:
                            targetoffsite[i]+=calc_cfd(i,j,gRNA)
                else:targetoffsite[i]="NA"
        else:targetoffsite={i:"NA" for i in targetseq}
        targetgc={i:str(round((i.count("G")+i.count("C"))/len(i),2)) for i in targetseq}
        # targetHairpin={i:"True" if "True" in str(primer3.calcHairpin(i)) else "False" for i in targetseq}
        # targetTm={i:str(int(primer3.calcTm(i))) for i in targetseq}
        ontarget={i:str(round(calc_score(seq[int(pos[:-1])-4:int(pos[:-1])+26]),2)) for i,pos in sgRNA_dir.items()}
        uniqjudge={seq:"True" if abs(judge)==10 else "False" for seq,judge in targetseq.items()}
        if name=="":
            with open(save,"w",encoding="utf-8") as f:
                f.write("sequence\tposition\tstrand\tGC\tActivity\tnum_mismatch\toff-target score\tunique\n")
                [f.write(infor+"\t"+pos[:-1]+"\t"+pos[-1]+"\t"+targetgc[infor]+"\t"+ontarget[infor]+"\t"+str(len(target_mis[infor]))+"\t"+str(targetoffsite[infor])+"\t"+uniqjudge[infor]+"\n") if "TTTT" not in infor and "AAAA" not in infor else f.write(infor+" ! \t"+pos[:-1]+"\t"+pos[-1]+"\t"+targetgc[infor]+"\t"+ontarget[infor]+"\t"+str(len(target_mis[infor]))+"\t"+str(targetoffsite[infor])+"\t"+uniqjudge[infor]+"\n") for infor,pos in sgRNA_dir.items()]
        else:
            if cs==True:name="common"
            with open(save+"_"+name+".txt","w",encoding="utf-8") as f:
                f.write("sequence\tposition\tstrand\tGC\tActivity\tnum_mismatch\toff-target score\tunique\n")
                [f.write(infor+"\t"+pos[:-1]+"\t"+pos[-1]+"\t"+targetgc[infor]+"\t"+ontarget[infor]+"\t"+str(len(target_mis[infor]))+"\t"+str(targetoffsite[infor])+"\t"+uniqjudge[infor]+"\n") if "TTTT" not in infor and "AAAA" not in infor else f.write(infor+" ! \t"+pos[:-1]+"\t"+pos[-1]+"\t"+targetgc[infor]+"\t"+ontarget[infor]+"\t"+str(len(target_mis[infor]))+"\t"+str(targetoffsite[infor])+"\t"+uniqjudge[infor]+"\n") for infor,pos in sgRNA_dir.items()]
    else:print("please change other PAM and try again. Because few sgRNA was detected in the selected Pam.")


def find_sgRNA(file,genome,save,sgRNA_length,databasename,pam,misnumber,common_sgRNA=False,not_unique=False):
    if file!="":
        if os.path.isfile(file)==False:
            find_sgRNA2(seq,save)
        else:
            seqdir={}
            with open(file,encoding="utf-8") as f:
                for line in f:
                    if ">" in line:
                        geneid=re.sub(r'[\/*?"<>|:]',"",line.split()[0])
                        seqdir[geneid]=""
                    else:
                        seqdir[geneid]+=line.strip()
            for ID,seq in seqdir.items():
                if common_sgRNA==False:
                    if not_unique==False:
                        find_sgRNA2(seq,file,genome,save,sgRNA_length,databasename,pam,misnumber,name=ID,cs=False,not_unique=False)
                    else:find_sgRNA2(seq,file,genome,save,sgRNA_length,databasename,pam,misnumber,name=ID,cs=False,not_unique=True)
                else:
                    find_sgRNA2(seq,file,genome,save,sgRNA_length,databasename,pam,misnumber,name=ID,cs=True)
                    break
    else:print("please input the target sequences or fasta file for searching sgRNAs")

def show_pam():
    pam_list=['ATTN', 'NNNRRT', 'NGA', 'TYCV', 'NGCG', 'NGAG', 'NG', 'NGD', 'NGG', 'TTV', 'NNGRRT', 'NRTH', 'NNAGAAW', 'TATG', 'NAA', 'TTTV', 'NRCH', 'NNG', 'VTTV', 'NRRH', 'TATV']
    for pam in pam_list:print(pam)

# def designprimers(file,save,f_seq,e_seq):
#     f_seq=f_seq.strip().upper()
#     e_seq=e_seq.strip().upper()
#     if os.path.exists(file)==False:
#         sgRNAsingle=file
#         f=f_seq+sgRNAsingle.strip()
#         r=reverse_complement(sgRNAsingle.strip()+e_seq)
#     else:
#         with open(file,encoding="utf-8") as f:
#             all=[(f_seq+line.split()[0].upper(),str(int(primer3.calcTm(f_seq+line.split()[0].upper()))),reverse_complement(line.split()[0].upper()+e_seq),str(int(primer3.calcTm(reverse_complement(line.split()[0].upper()+e_seq))))) for line in f if line.split()[0]!="sequence"]
#         if os.path.isdir(save):
#             with open(save+"/sgRNA_primers.txt","w",encoding="utf-8") as f:
#                 f.write(" \tPrimers(5'-3')\tTm\n")
#                 [f.write("F"+str(index+1)+":\t"+line[0]+"\t"+line[1]+"\nR"+str(index+1)+":\t"+line[2]+"\t"+line[3]+"\n") for index,line in enumerate(all)]
#         elif save!="":
#             with open(save,"w",encoding="utf-8") as f:
#                 f.write(" \tPrimers(5'-3')\tTm\n")
#                 [f.write("F"+str(index+1)+":\t"+line[0]+"\t"+line[1]+"\nR"+str(index+1)+":\t"+line[2]+"\t"+line[3]+"\n") for index,line in enumerate(all)]
#         elif save=="":
#             print("please set the save location and name your file!")

def filtersgRNA(file,save,percent,gccate):
    gcmin=float(gccate.split("-")[0])*0.01
    gcmax=float(gccate.split("-")[1])*0.01
    if os.path.isdir(save):save=save+"/filter_sgRNA_result.txt"
    with open(file,encoding="utf-8") as f:
        total_result=[line for line in f if "!" not in line and "sequence" not in line and line.split()[4]!="True"]
        offtarget_set={float(line.split()[-2]) for line in total_result}
        lists=list(offtarget_set)
        lists.sort()
        offtarget_theshold=lists[int(len(offtarget_set)*percent)]
        GC_list=[line for line in total_result if float(line.split()[-2])<=offtarget_theshold]
        finalresult=[line for line in GC_list if gcmin<=float(line.split()[3])<=gcmax]
    with open(save,"w",encoding="utf-8") as f:
        if finalresult!=[]:
            result="".join(finalresult)
            f.write(result)
        else:f.write("According to your setting, few sgRNAs can meet the thresholds. Therefore, please try it again, after changing the threshold.")

def designhpsgRNA(file,save,loopseq,gold,hairpin=False,golds=False):
        if os.path.isdir(save):save=save+"/structure_design.txt"
        if hairpin==True and loopseq=="":loopseq="ACAA"
        if golds==True and gold=="":gold="AAGGCTAGTCCGTTATCAACTTGGACTTCGGTCCAAGTGGCACCGAGTCGGTGCTTT"
        if os.path.exists(file)==True:
            if golds:
                with open(file,encoding="utf-8") as f,open(save,"w",encoding="utf-8") as f1:
                    [f1.write(line.split()[0]+gold+"\n") for line in f if "sequence" not in line]
            else:
                with open(file,encoding="utf-8") as f,open(save,"w",encoding="utf-8") as f1:
                    [f1.write(reverse_complement(line[:5])+loopseq+line.split()[0]+"\n") for line in f if "sequence" not in line]
        else:
            if golds:title=file.strip()+gold
            else:title=reverse_complement(file.strip()[:5])+loopseq+file.strip()
            print(title)

def exseqs(genome,position):
    results=''
    if os.access("./bin/seqkit",os.X_OK)==False:os.chmod("./bin/seqkit",stat.S_IXUSR)
    exe=os.path.abspath('./bin/seqkit')
    arg=exe+' faidx \n'+genome+'\n '+position
    arg=arg.replace("\n",'"')
    P = subprocess.Popen(arg, shell=True, stdout=subprocess.PIPE)
    lines = P.stdout.readlines()
    for line in lines:
        if '>' not in str(line,'utf-8'):
            results += str(line, 'utf-8')
    return results.replace('\n','')

def expromo(promoter_length,genome,gff,idfile,save):
    if promoter_length==None:promoter_length=2000
    else:promoter_length=int(promoter_length)
    if os.path.isdir(save):save=save+"/extract-promoters.txt"
    if os.path.isfile(idfile)==True:
        with open(idfile,encoding="utf-8") as f:
            idset={line.strip() for line in f if line!="\n"}
    else:idset={idfile.strip()}
    with open(gff,encoding="utf-8") as f,open(save,"w",encoding="utf-8") as f1:
        idlist=[(line.split("\t")[0],line.split("\t")[3],line.split("\t")[4],line.split("\t")[6],line.split("\t")[8].replace("ID=","").split(";")[0]) for line in f if "#" not in line and "mRNA" in line and line.split("\t")[8].replace("ID=","").split(";")[0] in idset]
        for infor in idlist:
            chrid,stp,edp,pos,geneid=infor
            if pos=="+":
                edp=int(stp)-1
                stp=int(stp)-promoter_length
                if stp<0:stp=1
                position=chrid+":"+str(stp)+"-"+str(edp)
                sequence=exseqs(genome,position)
            else:
                stp=int(edp)+1
                edp=stp+promoter_length-1
                position=chrid+":"+str(stp)+"-"+str(edp)
                sequence=reverse_complement(exseqs(genome,position))
            print(">"+geneid+"\n"+sequence,file=f1)

def exmRNA(genome,gff,idfile,save):
    if os.path.isdir(save):save=save+"/extract-totallength.txt"
    if os.path.isfile(idfile)==True:
        with open(idfile,encoding="utf-8") as f:
            idset={line.strip() for line in f if line!="\n"}
    else:idset={idfile.strip()}
    with open(gff,encoding="utf-8") as f,open(save,"w",encoding="utf-8") as f1:
        idlist=[(line.split("\t")[0],line.split("\t")[3],line.split("\t")[4],line.split("\t")[6],line.split("\t")[8].replace("ID=","").split(";")[0]) for line in f if "#" not in line and "mRNA" in line and line.split("\t")[8].replace("ID=","").split(";")[0] in idset]
        for infor in idlist:
            chrid,stp,edp,pos,geneid=infor
            if pos=="+":
                position=chrid+":"+str(stp)+"-"+str(edp)
                sequence=exseqs(genome,position)
            else:
                position=chrid+":"+str(stp)+"-"+str(edp)
                sequence=reverse_complement(exseqs(genome,position))
            print(">"+geneid+"\n"+sequence,file=f1)

def utr(kd,genome,gff,idfile,save):
    if kd=="five":
        if os.path.isdir(save):save=save+"/extract-5UTRs.txt"
    else:
        if os.path.isdir(save):save=save+"/extract-3UTRs.txt"
    if os.path.isfile(idfile)==True:
        with open(idfile,encoding="utf-8") as f:
            idset={line.strip() for line in f if line!="\n"}
    else:idset={idfile.strip()}
    with open(gff,encoding="utf-8") as f,open(save,"w",encoding="utf-8") as f1:
        idlist=[(line.split("\t")[0],line.split("\t")[3],line.split("\t")[4],line.split("\t")[6],line.split("\t")[8].replace("ID=","").split(";")[0]) for line in f if "#" not in line and kd in line and line.split("\t")[8].replace("ID=","").split("."+kd)[0] in idset]
        for infor in idlist:
            chrid,stp,edp,pos,geneid=infor
            if pos=="+":
                position=chrid+":"+str(stp)+"-"+str(edp)
                sequence=exseqs(genome,position)
            else:
                position=chrid+":"+str(stp)+"-"+str(edp)
                sequence=reverse_complement(exseqs(genome,position))
            print(">"+geneid+"\n"+sequence,file=f1)

def excds(filepath,idfile,save):
    indexfile=filepath+".index"
    if os.path.isdir(save):save=save+"/extract_cds.txt"
    if os.path.exists(filepath+".index")==False:
        with open(filepath,"rb") as f:
            indexs={}
            index=f.tell()
            line=f.readline()
            while line:
                if ">".encode() in line:
                    ID=line.split()[0][1:]
                    indexs[ID]=index
                index=f.tell()
                line=f.readline()
        with open(filepath+".index","wb") as f:
            pickle.dump(indexs,f)
    with open(indexfile,"rb") as f:
        indexs=pickle.load(f)
    if os.path.isfile(idfile):
        with open(idfile,encoding="utf-8") as f:
            geneids=f.readlines()
    else:geneids=[idfile]
    with open(filepath,"rb") as f2,open(save,"w",encoding="utf-8") as f1:
        for line in geneids:
            if line!="\n" and line!="":
                ID=line.strip()
                print(">"+ID,file=f1)
                ID=ID.encode()
                if ID in indexs:
                    f2.seek(indexs[ID])
                    count=0
                    for line in f2:
                        if line.startswith(">".encode()):
                            count+=1
                        else:
                            print(line.decode().strip(),file=f1)
                        if count==2:
                            break

def extseqs(file,save,genome):
    if os.path.isdir(save):save=save+"/extract-totallength.txt"
    with open(file,encoding="utf-8") as f,open(save,"w",encoding="utf-8") as f1:
        for line in f:
            geneid,chrid,stp,edp,pos=line.strip().split()#格式是基因ID,CHR ID,起始位置，终止位置，正负链
            if pos=="+":
                    position=chrid+":"+str(stp)+"-"+str(edp)
                    sequence=exseqs(genome,position)
            else:
                position=chrid+":"+str(stp)+"-"+str(edp)
                sequence=reverse_complement(exseqs(genome,position))
            print(">"+geneid+"\n"+sequence,file=f1)

def exID(gffile,save):
    if save=="" or os.path.isdir(save)==True:
        if save=="":save="./extract_IDs.txt"
        else:save=save+"/extract_IDs.txt"
    with open(gffile,encoding="utf-8") as f,open(save,"w",encoding="utf-8") as f1:
        [print(line.split("\t")[8].replace("ID=","").split(";")[0],file=f1) for line in f if "#" not in line and "mRNA" in line]

def transformatgff(path,outpath):
    fw=open(outpath,"w")
    with open (path,encoding="utf-8") as f,open(outpath,"w",encoding="utf-8") as f1:
        for line in f:
            line=line.strip()
            if line[0] !="#":
                cols=line.split()
                if cols[2]=="mRNA":
                    fw.write(line+"\n")
                else :
                    cl8=cols[8].split(";")
                    if "Parent" in cl8[0]:
                        print(line.replace("Parent","ID"),file=f1)
                    elif "Parent" in cl8[1]:
                        print(line.replace(cl8[0]+";","").replace("Parent","ID"),file=f1)
    fw.close()

def transformatgtf(path,outpath):
    with open (path,encoding="utf-8") as f,open(outpath,"w",encoding="utf-8") as f1:
        for line in f:
            line=line.strip()
            if line[0] !="#":
                cols=line.split("\t")
                cl8=cols[8].split(";",1)
                cl8[0]="ID="+cl8[0].split("\"")[1]
                newline="\t".join(cols[:8]).replace("gene","mRNA")+"\t"+cl8[0]+";"+cl8[1]
                print(newline,file=f1)

def changeformat(file,save):
    if ".gtf" in os.path.split(file)[-1]:
        if os.path.isdir(save):save=save+"/changeformat.gff3"
        transformatgtf(file,save)
    else:
        if os.path.isdir(save):save=save+"/changeformat.gff3"
        transformatgff(file,save)

if __name__ == '__main__':
    pams={"NGG":["AGG","GGG","CGG","AGG"],"NGA":["AGA","GGA","CGA","TGA"],"NGAG":["AGAG","GGAG","CGAG","TGAG"],
        "NGCG":["AGCG","GGCG","CGCG","TGCG"],"NG":["AG","GG","CG","TG"],"NAA":["AAA","GAA","CAA","TAA"],"GAA":["GAA"],"GAT":["GAT"],
        "NNGRRT":['AAGAAT', 'AAGAGT', 'AAGGAT', 'AAGGGT', 'AGGAAT', 'AGGAGT', 'AGGGAT', 'AGGGGT', 'ACGAAT', 'ACGAGT', 'ACGGAT', 'ACGGGT', 'ATGAAT', 'ATGAGT', 'ATGGAT', 'ATGGGT', 'GAGAAT', 'GAGAGT', 'GAGGAT', 'GAGGGT', 'GGGAAT', 'GGGAGT', 'GGGGAT', 'GGGGGT', 'GCGAAT', 'GCGAGT', 'GCGGAT', 'GCGGGT', 'GTGAAT', 'GTGAGT', 'GTGGAT', 'GTGGGT', 'CAGAAT', 'CAGAGT', 'CAGGAT', 'CAGGGT', 'CGGAAT', 'CGGAGT', 'CGGGAT', 'CGGGGT', 'CCGAAT', 'CCGAGT', 'CCGGAT', 'CCGGGT', 'CTGAAT', 'CTGAGT', 'CTGGAT', 'CTGGGT', 'TAGAAT', 'TAGAGT', 'TAGGAT', 'TAGGGT', 'TGGAAT', 'TGGAGT', 'TGGGAT', 'TGGGGT', 'TCGAAT', 'TCGAGT', 'TCGGAT', 'TCGGGT', 'TTGAAT', 'TTGAGT', 'TTGGAT', 'TTGGGT'],
        "NNNRRT":['AAAAAT', 'AAAAGT', 'AAAGAT', 'AAAGGT', 'AAGAAT', 'AAGAGT', 'AAGGAT', 'AAGGGT', 'AACAAT', 'AACAGT', 'AACGAT', 'AACGGT', 'AATAAT', 'AATAGT', 'AATGAT', 'AATGGT', 'AGAAAT', 'AGAAGT', 'AGAGAT', 'AGAGGT', 'AGGAAT', 'AGGAGT', 'AGGGAT', 'AGGGGT', 'AGCAAT', 'AGCAGT', 'AGCGAT', 'AGCGGT', 'AGTAAT', 'AGTAGT', 'AGTGAT', 'AGTGGT', 'ACAAAT', 'ACAAGT', 'ACAGAT', 'ACAGGT', 'ACGAAT', 'ACGAGT', 'ACGGAT', 'ACGGGT', 'ACCAAT', 'ACCAGT', 'ACCGAT', 'ACCGGT', 'ACTAAT', 'ACTAGT', 'ACTGAT', 'ACTGGT', 'ATAAAT', 'ATAAGT', 'ATAGAT', 'ATAGGT', 'ATGAAT', 'ATGAGT', 'ATGGAT', 'ATGGGT', 'ATCAAT', 'ATCAGT', 'ATCGAT', 'ATCGGT', 'ATTAAT', 'ATTAGT', 'ATTGAT', 'ATTGGT', 'GAAAAT', 'GAAAGT', 'GAAGAT', 'GAAGGT', 'GAGAAT', 'GAGAGT', 'GAGGAT', 'GAGGGT', 'GACAAT', 'GACAGT', 'GACGAT', 'GACGGT', 'GATAAT', 'GATAGT', 'GATGAT', 'GATGGT', 'GGAAAT', 'GGAAGT', 'GGAGAT', 'GGAGGT', 'GGGAAT', 'GGGAGT', 'GGGGAT', 'GGGGGT', 'GGCAAT', 'GGCAGT', 'GGCGAT', 'GGCGGT', 'GGTAAT', 'GGTAGT', 'GGTGAT', 'GGTGGT', 'GCAAAT', 'GCAAGT', 'GCAGAT', 'GCAGGT', 'GCGAAT', 'GCGAGT', 'GCGGAT', 'GCGGGT', 'GCCAAT', 'GCCAGT', 'GCCGAT', 'GCCGGT', 'GCTAAT', 'GCTAGT', 'GCTGAT', 'GCTGGT', 'GTAAAT', 'GTAAGT', 'GTAGAT', 'GTAGGT', 'GTGAAT', 'GTGAGT', 'GTGGAT', 'GTGGGT', 'GTCAAT', 'GTCAGT', 'GTCGAT', 'GTCGGT', 'GTTAAT', 'GTTAGT', 'GTTGAT', 'GTTGGT', 'CAAAAT', 'CAAAGT', 'CAAGAT', 'CAAGGT', 'CAGAAT', 'CAGAGT', 'CAGGAT', 'CAGGGT', 'CACAAT', 'CACAGT', 'CACGAT', 'CACGGT', 'CATAAT', 'CATAGT', 'CATGAT', 'CATGGT', 'CGAAAT', 'CGAAGT', 'CGAGAT', 'CGAGGT', 'CGGAAT', 'CGGAGT', 'CGGGAT', 'CGGGGT', 'CGCAAT', 'CGCAGT', 'CGCGAT', 'CGCGGT', 'CGTAAT', 'CGTAGT', 'CGTGAT', 'CGTGGT', 'CCAAAT', 'CCAAGT', 'CCAGAT', 'CCAGGT', 'CCGAAT', 'CCGAGT', 'CCGGAT', 'CCGGGT', 'CCCAAT', 'CCCAGT', 'CCCGAT', 'CCCGGT', 'CCTAAT', 'CCTAGT', 'CCTGAT', 'CCTGGT', 'CTAAAT', 'CTAAGT', 'CTAGAT', 'CTAGGT', 'CTGAAT', 'CTGAGT', 'CTGGAT', 'CTGGGT', 'CTCAAT', 'CTCAGT', 'CTCGAT', 'CTCGGT', 'CTTAAT', 'CTTAGT', 'CTTGAT', 'CTTGGT', 'TAAAAT', 'TAAAGT', 'TAAGAT', 'TAAGGT', 'TAGAAT', 'TAGAGT', 'TAGGAT', 'TAGGGT', 'TACAAT', 'TACAGT', 'TACGAT', 'TACGGT', 'TATAAT', 'TATAGT', 'TATGAT', 'TATGGT', 'TGAAAT', 'TGAAGT', 'TGAGAT', 'TGAGGT', 'TGGAAT', 'TGGAGT', 'TGGGAT', 'TGGGGT', 'TGCAAT', 'TGCAGT', 'TGCGAT', 'TGCGGT', 'TGTAAT', 'TGTAGT', 'TGTGAT', 'TGTGGT', 'TCAAAT', 'TCAAGT', 'TCAGAT', 'TCAGGT', 'TCGAAT', 'TCGAGT', 'TCGGAT', 'TCGGGT', 'TCCAAT', 'TCCAGT', 'TCCGAT', 'TCCGGT', 'TCTAAT', 'TCTAGT', 'TCTGAT', 'TCTGGT', 'TTAAAT', 'TTAAGT', 'TTAGAT', 'TTAGGT', 'TTGAAT', 'TTGAGT', 'TTGGAT', 'TTGGGT', 'TTCAAT', 'TTCAGT', 'TTCGAT', 'TTCGGT', 'TTTAAT', 'TTTAGT', 'TTTGAT', 'TTTGGT'],
        "NNAGAAW":['AAAGAAA', 'AAAGAAT', 'AGAGAAA', 'AGAGAAT', 'ACAGAAA', 'ACAGAAT', 'ATAGAAA', 'ATAGAAT', 'GAAGAAA', 'GAAGAAT', 'GGAGAAA', 'GGAGAAT', 'GCAGAAA', 'GCAGAAT', 'GTAGAAA', 'GTAGAAT', 'CAAGAAA', 'CAAGAAT', 'CGAGAAA', 'CGAGAAT', 'CCAGAAA', 'CCAGAAT', 'CTAGAAA', 'CTAGAAT', 'TAAGAAA', 'TAAGAAT', 'TGAGAAA', 'TGAGAAT', 'TCAGAAA', 'TCAGAAT', 'TTAGAAA', 'TTAGAAT'],
        "NNG":['AAG', 'AGG', 'ACG', 'ATG', 'GAG', 'GGG', 'GCG', 'GTG', 'CAG', 'CGG', 'CCG', 'CTG', 'TAG', 'TGG', 'TCG', 'TTG'],
        "NGD":['AGA', 'AGG', 'AGT', 'GGA', 'GGG', 'GGT', 'CGA', 'CGG', 'CGT', 'TGA', 'TGG', 'TGT'],"NAN":['AAA', 'AAG', 'AAC', 'AAT', 'GAA', 'GAG', 'GAC', 'GAT', 'CAA', 'CAG', 'CAC', 'CAT', 'TAA', 'TAG', 'TAC', 'TAT'],
        "NRRN":['AAAA', 'AAGA', 'AGAA', 'AGGA', 'AAAG', 'AAGG', 'AGAG', 'AGGG', 'AAAC', 'AAGC', 'AGAC', 'AGGC', 'AAAT', 'AAGT', 'AGAT', 'AGGT', 'GAAA', 'GAGA', 'GGAA', 'GGGA', 'GAAG', 'GAGG', 'GGAG', 'GGGG', 'GAAC', 'GAGC', 'GGAC', 'GGGC', 'GAAT', 'GAGT', 'GGAT', 'GGGT', 'CAAA', 'CAGA', 'CGAA', 'CGGA', 'CAAG', 'CAGG', 'CGAG', 'CGGG', 'CAAC', 'CAGC', 'CGAC', 'CGGC', 'CAAT', 'CAGT', 'CGAT', 'CGGT', 'TAAA', 'TAGA', 'TGAA', 'TGGA', 'TAAG', 'TAGG', 'TGAG', 'TGGG', 'TAAC', 'TAGC', 'TGAC', 'TGGC', 'TAAT', 'TAGT', 'TGAT', 'TGGT'],"NRCH":['AACA', 'AACC', 'AACT', 'AGCA', 'AGCC', 'AGCT', 'GACA', 'GACC', 'GACT', 'GGCA', 'GGCC', 'GGCT', 'CACA', 'CACC', 'CACT', 'CGCA', 'CGCC', 'CGCT', 'TACA', 'TACC', 'TACT', 'TGCA', 'TGCC', 'TGCT'],"NRTH":['AATA', 'AATC', 'AATT', 'AGTA', 'AGTC', 'AGTT', 'GATA', 'GATC', 'GATT', 'GGTA', 'GGTC', 'GGTT', 'CATA', 'CATC', 'CATT', 'CGTA', 'CGTC', 'CGTT', 'TATA', 'TATC', 'TATT', 'TGTA', 'TGTC', 'TGTT'],
        "TTTV":['TTTA', 'TTTG', 'TTTC'],"TYCV":['TCCA', 'TTCA', 'TCCG', 'TTCG', 'TCCC', 'TTCC'],"CCCC":["CCCC"],"TATV":['TATA', 'TATG', 'TATC'],"TATG":["TATG"],
        "VTTV":['ATTA', 'ATTG', 'ATTC', 'GTTA', 'GTTG', 'GTTC', 'CTTA', 'CTTG', 'CTTC'],"ATTN":['ATTA', 'ATTG', 'ATTC', 'ATTT'],"TTV":['TTA', 'TTG', 'TTC'],
        "CCCV":['CCCA', 'CCCG', 'CCCC'],"CTCV":['CTCA', 'CTCG', 'CTCC']}
    args = argparseFunc()
    genome=args.genome_file
    save=args.out
    database=args.database_file
    fasta_file=args.fasta_file
    if args.make_database:
        if genome==None:print("please input the pathway of genome sequence file.")
        else:
            if save==None:save=genome+"_sgRNA_database.txt"
            sgrna_l=args.sgRNA_length
            make_database(genome,save,sgrna_l)
    if args.search_sgRNA:
        if args.not_unique:not_unique=True
        else:not_unique=False
        sgRNA_length=args.sgRNA_length
        databasename=args.database_file
        pam=args.pam;misnumber=args.misnumber
        if args.common_sgRNA:common_sgRNAs=True
        else:common_sgRNAs=False
        find_sgRNA(fasta_file,genome,save,sgRNA_length,databasename,pam,misnumber,common_sgRNA=common_sgRNAs,not_unique=not_unique)
    if args.show_pams:show_pam()
    # if args.design_primer:
    #     file=args.sgRNA_file
    #     f_seq=args.left_region
    #     if f_seq==False:print("please input the sequence on the left side of the sgRNA insert site")
    #     e_seq=args.right_region
    #     if e_seq==False:print("please input the sequence on the right side of the sgRNA insert site")
    #     designprimers(file,save,f_seq,e_seq)
    if args.filter_sgRNA:
        file=args.sgRNA_file
        percent=args.filter_percent
        gc_content=args.gc_range
        filtersgRNA(file,save,percent,gc_content)
    if args.add_hairpin:
        file=args.sgRNA_file
        loopseq=args.hairpin
        gold=args.gold_structure
        designhpsgRNA(file,save,loopseq,gold,hairpin=True,golds=False)
    if args.add_gold:
        file=args.sgRNA_file
        loopseq=args.hairpin#需要实验一下，如果不加参数，会返回什么
        gold=args.gold_structure
        designhpsgRNA(file,save,loopseq,gold,hairpin=False,golds=True)
    if args.extract_promoter:
        promoter_length=args.promoter_length
        gff=args.gff_file
        idfile=args.ID_file
        expromo(promoter_length,genome,gff,idfile,save)
    if args.extract_total:
        gff=args.gff_file
        idfile=args.ID_file
        exmRNA(genome,gff,idfile,save)
    if args.extract_5utr:
        gff=args.gff_file
        idfile=args.ID_file
        utr("five",genome,gff,idfile,save)
    if args.extract_3utr:
        gff=args.gff_file
        idfile=args.ID_file
        utr("three",genome,gff,idfile,save)
    if args.extract_cds:
        idfile=args.ID_file
        excds(fasta_file,idfile,save)
    if args.extract_bed:
        file=args.bed_file
        extseqs(file,save,genome)
    if args.extract_ids:
        gffile=args.gff_file
        exID(gffile,save)
    if args.formatgtf:
        file=args.gtf_file
        changeformat(file,save)







    

