import argparse
import subprocess
def argparseFunc():
    parser = argparse.ArgumentParser(description="design sgRNA")
    #the input files
    parser.add_argument("-gf","--genome_file")
    parser.add_argument("-ff","--fasta_file")
    parser.add_argument("-count",default="5")
    #the save file
    parser.add_argument("-o","--out",help="save path")
    parser.add_argument("-ss","--search_sgRNA",action="store_true",help="search sgRNAs")
    return parser.parse_args()

def function(count,fasta,genome,result):
    a='./bin/seqmap '+count+" " +fasta+' ' +genome+" "+result+' /output_all_matches'
    result=subprocess.Popen(a,shell=True)
    result.wait()

if __name__ == '__main__':
    args = argparseFunc()
    if args.search_sgRNA:
        genome=args.genome_file
        save=args.out
        fasta_file=args.fasta_file
        count=args.count
        function(count,fasta_file,genome,save)